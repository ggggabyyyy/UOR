<?php include("../connection.php"); ?>

<!DOCTYPE html>
<!-- l'attribut lang permet de définir la langue utilisée pour l'élément. Ici on utilise le français sur l'ensemble du document -->
<html lang="fr">
	<head>
		<title>Idées de voyages à vélo</title>

		<!-- permet de définir l'encodage des caractères -->
		<meta charset="utf-8">

		<!-- Permet de déclarer les 15 propriétés originales du Dublin Core -->
		<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
		<!-- Permet de déclarer d'autres propriétés du Dublin Core -->
		<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" />

		<!-- affectations des valeurs aux propriétés -->
		<meta name="DC.title" content="Idées de voyages à vélo">
		<meta name="DC.creator" content="Le touriste">
		<meta name="DC.subject" content="voyages, vélo, cyclotourisme">
		<meta name="DC.description" content="idées de projet de voyages en vélo">
		<meta name="DC.date" content="2021-08">
		<meta name="DC.type" content="text">
		<meta name="DC.source" content="https://fr.eurovelo.com, https://www.lfzuiderzeeroute.nl, https://www.avenuevertelondonparis.com/">
		<meta name="DC.language" content="fr">
		<meta name="DCTERMS.tableOfContents" content="Le Rhône à vélo de Andermatt à Genève, Le tour de l'IJsselmeer à vélo en partant d'Amsterdam, Paris - Londres">

		<!-- permet d'afficher le logo du site dans le navigateur -->
		<link rel="icon" type="image/png" href="../images/bicycle.png" />

		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="style.css">

		<!-- Bootsrap CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	</head>
	<body>
		<?php include("../nav.php"); ?>
		<div>
			<?php
				function nettoyer($x){
					if ($x){
						$x = trim($x);
						$x = stripcslashes($x);
						$x = htmlspecialchars($x);
					}
					return $x;
				}
				$cleaned_data = array();
				foreach ($_POST as $key => $value) {
					$cleaned_data[$key] = nettoyer($value);
				}


				// $mysqli->real_escape_string() sert à échapper les caractères spéciaux du SQL comme l'apostrophe.
				$sql = sprintf("INSERT INTO commentaire VALUES (null, '%s', '%s', STR_TO_DATE('%s', '%%Y-%%m-%%d'), '%s', STR_TO_DATE('%s', '%%Y-%%m-%%d'), %s)",
						$mysqli->real_escape_string($cleaned_data['prenom']),
						$mysqli->real_escape_string($cleaned_data['email']),
						$cleaned_data['date-naissance'],
						$mysqli->real_escape_string($cleaned_data['commentaire']),
						date("Y-m-d"),
						// si aucun voyage n'a été selectionné on entre la valeur null dans la requete sql
						$cleaned_data['voyage-favori'] == "" ? "null" : $cleaned_data['voyage-favori']);
				$mysqli->query($sql);
				// Si il y a eu une erreur lors de la requête $mysqli->affected_rows retourne -1
				if ($mysqli->affected_rows != -1)
					{
			?>
				<h2>
					Merci <?php echo $cleaned_data['prenom'] ?> pour votre commentaire.
				</h2>
				<p>
					Votre date de naissance enregistrée est : <?php echo $cleaned_data['date-naissance']; ?>
				</p>
				<p>
					Votre adresse email enregistrée est : <?php echo $cleaned_data['email']; ?>
				</p>
				<!-- Si un voyage a été sélectionné dans le formualire on affiche son nom -->
				<?php
					if ($cleaned_data['voyage-favori'] != "") {
						$sql = "SELECT nom FROM voyage WHERE id=" . $cleaned_data['voyage-favori'];
						$result = $mysqli->query($sql);
						$row = $result->fetch_row();
						echo "<p>Votre parcours préferé est : ".$row[0].".</p>";
					}
				} else {
					echo "<p>Une erreur c'est produite lors de l'enregistrement des données</p>";
				}
			?>
		</div>
	</body>
</html>