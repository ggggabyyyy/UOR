function afficher(elts, nb) {
	for (i=0; i < elts.length; i++) {
		if (i < nb) {
			elts[i].hidden = false;
		} else {
			elts[i].hidden = true;
		}
	}
}

var commentaires = document.getElementsByClassName('commentaire');
var bouton = document.getElementById('plus-de-commentaires');


// si il y a plus de deux commentaires on affiche seulement les deux premiers
// et on affiche le bouton "plus de commentaires"
if (commentaires.length > 2) {
	afficher(commentaires, 2);
	bouton.hidden = false;
}


// si on clique sur le bouton plus de commentaires, tout les commentaire s'affiche
bouton.onclick =  function() {
	afficher(commentaires, commentaires.length);
	bouton.hidden = true;
};


var commenter = document.getElementById('commenter');
var commenterBouton = document.getElementById('commenter-btn');

commenterBouton.onclick =  function() {
	commenter.hidden = false;
	commenterBouton.hidden = true;
};


