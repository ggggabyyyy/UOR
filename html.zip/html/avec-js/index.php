
<?php include("../connection.php"); ?>


<!DOCTYPE html>
<!-- l'attribut lang permet de définir la langue utilisée pour l'élément. Ici on utilise le français sur l'ensemble du document -->
<html lang="fr">
	<head>
		<title>Idées de voyage à vélo</title>

		<!-- permet de définir l'encodage des caractères -->
		<meta charset="utf-8">

		<!-- Permet de déclarer les 15 propriétés originales du Dublin Core -->
		<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
		<!-- Permet de déclarer d'autres propriétés du Dublin Core -->
		<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" />

		<!-- affectations des valeurs aux propriétés -->
		<meta name="DC.title" content="Idées de voyage à vélo">
		<meta name="DC.creator" content="Le touriste">
		<meta name="DC.subject" content="voyages, vélo, cyclotourisme">
		<meta name="DC.description" content="idées de projet de voyage en vélo">
		<meta name="DC.date" content="2021-08">
		<meta name="DC.type" content="text">
		<meta name="DC.source" content="https://fr.eurovelo.com, https://www.lfzuiderzeeroute.nl, https://www.avenuevertelondonparis.com/">
		<meta name="DC.language" content="fr">
		<meta name="DCTERMS.tableOfContents" content="Le Rhône à vélo de Andermatt à Genève, Le tour de l'IJsselmeer à vélo en partant d'Amsterdam, Paris - Londres">

		<!-- permet d'afficher le logo du site dans le navigateur -->
		<link rel="icon" type="image/png" href="../images/bicycle.png" />

		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="style.css">

		<!-- Bootsrap CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	</head>
	<body>

		<?php include("../nav.php"); ?>
		
		<!-- je place dans l'en tête le titre de la page et une petite intro -->
		<header>
			<div class="container">
				<h1>Quelques idées de voyage à vélo</h1>
				<p class="lead">Suite à une super expérience de voyage à vélo le long de la côte atlantique de Nantes à Arcachon, j'ai prévu de faire d'autres voyages à vélo. En voici quelques-uns.</p>
			</div>
		</header>

		<!-- On ajoute un bloc conteneur pour partager l'espace de manière 'responsive' entre le bloc articles et le bloc aside.
				 On place le bloc aside sur la droite du bloc articles sur les grands écrans et en dessous sur les tablettes / téléphones
				 de manière à ceux que chaque bloc puisse prendre toute la largeur de l'écran et ainsi restait lisible  -->
		<div class="container">
			<div class="row">

				<!-- bloc divisé en trois articles -->
				<div id="articles" class="col-12 col-xl-8">
					<article>
						<!-- chaque article possède un titre en h2 pour différencier du titre de la page -->
						<h2>Le Rhône à vélo de Andermatt à Genève</h2>

						<!-- Ici aussi on partage l'espace de manière 'responsive' entre l'image et le paragraphe
								 qui sont situés sur la même ligne sur les écrans suffisament grand -->
						<div class="row">
							<div class="col-12 col-lg-5">
								<!-- une image qui montre la carte du parcours -->
								<img src="../images/carte_route_du_rhone.png" class="img-fluid" alt="carte de l'itinéraire de la route du Rhône">
							</div>
							<div class="col-12 col-lg-7">
								<!-- un premier paragraphe qui parle du parcours 
									j'ai mis en avant les 3700m pour éviter que l'on s'attarde sur cet article
									si l'on veut un voyage moins exigeant -->
								<p>
									Parcours de 350km dans la vallée du Rhône, en partant d'Andermatt, une petite ville située dans l'une des vallées les plus imposante de Suisses. En tout <em>3700 m de montée cumulée</em>, située essentiellement en début de parcours pour rejoindre le glacier du Rhône. Le dénivelé du parcours est de -1000m. Pour les plus sportifs il peut être intéressant de le faire dans l'autre sens.
								</p>
							</div>
						</div>

						<!-- une partie qui liste des sites à voir sur le parcours -->
						<div class="highlights">
							<h3>A voir sur le parcours:</h3>
							<ul>
								<li><a href="https://fr.wikipedia.org/wiki/Glacier_du_Rh%C3%B4ne">le glacier du Rhône</a></li>
								<li><a href="https://fr.wikipedia.org/wiki/Ch%C3%A2teau_de_Stockalper">le Chateau Kaspar Stockalper</a></li>
								<li>le lac Léman et les villes de Lausanne et Genève</li>
							</ul>
						</div>

						<!-- une dernière partie pour des infos pratiques et des liens pour approfondir le sujet -->
						<div class="info bg-light">
							<p>
								Accès à Andermatt depuis Paris : environ 7h-8h en train<br>
								Pour plus d'info sur le parcours : le site de <a href="https://www.schweizmobil.ch/fr/suisse-a-velo/itineraires/route-01.html">schweizmobil</a> ou d'<a href="https://fr.eurovelo.com/ev17/points-of-interest-on-eurovelo-17">eurovelo</a>
							</p>
						</div>
					</article>

					<article>
						<h2>Le tour de l'IJsselmeer à vélo en partant d'Amsterdam</h2>
						<div class="row">
							<div class="col-12 col-lg-5">
								<img src="../images/carte_zuiderzeeroute.png" class="img-fluid" alt="carte de l'itinéraire de la zuiderzeeroute">
							</div>
							<div class="col-12 col-lg-7">
								<p>
									La zuiderzeeroute est très plate (une évidence aux Pays-Bas) et est longue de 440km. Elle fait le tour de l'IJsselmeer en passant par <a href="https://fr.wikipedia.org/wiki/Afsluitdijk">l'Afsluitdijk</a> <em>une digue de 32km!</em> Ce parcours est à faire de préference entre mi-avril et fin mai pour profiter des <a href="https://www.holland.com/fr/tourisme/destinations/les-provinces/flevoland/fleurs-en-flevoland.htm">champs de tulipes du Flevoland</a>
								</p>
							</div>
						</div>
						<div class="highlights">
							<h3>A voir sur le parcours:</h3>
							<ul>
								<li>Amsterdam</li>
								<li>les champs de tulipes (mi-avril à mai à Dronten, Lelystad et Putten)</li>
								<li>les moulins</li>
							</ul>
						</div>
						<div class="info bg-light">
							<p>
								Accès à Amsterdam depuis Paris : 2h en train<br>
								Pour plus d'info sur le parcours : <a href="https://www.lfzuiderzeeroute.nl/en">lfzuiderzeeroute.nl/en</a>
							</p>
						</div>
					</article>

					<article>
						<h2>Paris - Londres</h2>
						<div class="row">
							<div class="col-12 col-lg-5">
								<img src="../images/carte_paris_londres.png" class="img-fluid" alt="carte de l'itinéraire Paris-Londres">
							</div>
							<div class="col-12 col-lg-7">
								<p>
									Départ de Paris puis passage par la vallée de l'Epte en Normandie avant de rejoindre Dieppe. La traversée de la Manche se fait en 3h de <a href="https://www.dfds.com/fr-fr/ferries-passagers/lignes-ferries/ferries-vers-angleterre/dieppe-newhaven">ferry de Dieppe à Newhaven</a>. Il reste ensuite 159km pour rejoindre la capitale Britannique. Une alternative et de longer les bords de l'Oise avant de se diriger vers la Normandie, ce qui rallonge le parcours de 66km mais permet de longer plusieurs jolis châteaux au passage.
								</p>
							</div>
						</div>
						<div class="highlights">
							<h3>A voir sur le parcours:</h3>
							<ul>
								<li><a href="https://fr.wikipedia.org/wiki/Fondation_Claude_Monet">la Fondation Claude Monet à Giverny</a></li>
								<li>quelques châteaux à voir, comme par exemple celui de <a href="https://fr.wikipedia.org/wiki/Ch%C3%A2teau_de_Gisors">Gisors</a></li>
								<li>et Londres bien sûr.</li>
							</ul>
						</div>
						<div class="info bg-light">
							<p>
								retour Londres-Paris : 2h20 en train<br>
								Pour plus d'info sur le parcours : <a href="https://www.avenuevertelondonparis.com/">avenuevertelondonparis.com</a>
							</p>
						</div>
					</article>
				</div>
				
				<div class="col-12  col-xl-4">

					<!-- un tableau récapitulatif des voyages placé entre les balises aside
							 cela permettra d'avoir un aperçu rapide sur les différents voyages -->

					<!-- on fixe le bloc aside en haut de l'écran pour qu'il reste apparant sur les grand écrans -->
					<aside class="sticky-top">
						<h2>Tableau récapitulatif des voyages</h2>
						<?php
							$sql = "SELECT * FROM voyage
										LEFT JOIN
											(SELECT voyage_favori, count(voyage_favori) AS cnt
												FROM commentaire GROUP BY voyage_favori )
											AS fav
										ON voyage.id=fav.voyage_favori";
							$res = $mysqli->query($sql);
						?>
						<table class="table table-striped">
							<tr>
								<th>trajet</th>
								<th>paysage</th>
								<th>période</th>
								<th>distance</th>
								<th>durée</th>
								<th>vote</th>
							</tr>
						<?php
							while ($row = $res->fetch_assoc()) {
						?>
							<tr>
								<td><?php echo $row['nom'];?></td>
								<td><?php echo $row['payasge'];?></td>
								<td><?php echo $row['periode'];?></td>
								<td><?php echo $row['distance_km'];?> km</td>
								<td><?php echo $row['duree_j'];?> j.</td>
								<td><?php if (empty($row['cnt'])) {echo 0;} else {echo $row['cnt'];}?></td>
							</tr>
						<?php
							}
						?>
						</table>
					</aside>
				</div>
				<div>
					<button id="commenter-btn" type="button" class="btn btn-secondary btn-sm btn-lg col-12 mb-4">Commenter cet article</button>
					<form hidden id="commenter" class="pt-4 pb-4" action="form.php" method="POST">
						<div class="row">
							<div class="col-12 col-lg-5 mb-3">
								<label for="prenom" class="form-label">Nom</label>
								<input type="text" class="form-control" id="prenom" name="prenom" required maxlength="15" size="15">
							</div>

							<!-- L'input de type email vérifie automatique si la saisie est de la forme d'un email -->
							<div class="col-12 col-lg-5 mb-3">
								<label for="email" class="form-label">Adresse email</label>
								<input type="email" class="form-control" id="email" name="email" aria-describedby="emailAide" size="30" required>
								<div id="emailAide" class="form-text">L'adresse email ne sera pas partagée.</div>
							</div>

							<!-- L'input de type date permet de sélectionner directement une date,
								 puisque on ne peut pas être né dans le futur la date maximum séléctionnable est la date du jour -->
							<div class="col-12 col-lg-2 mb-3">
								<label for="date-naissance" class="form-label">Date de naissance</label>
								<input type="date" class="form-control" id="date-naissance" name="date-naissance" aria-describedby="dateAide" max= <?php echo date("Y-m-d"); ?> required>
								<div id="dateAide" class="form-text">Votre date de naissance ne sera pas partagée.</div>
							</div>
						</div>
						<div class="mb-3">
							<label for="commentaire" class="form-label">Commentaire</label>
							<textarea class="form-control" id="commentaire" name="commentaire" rows="3" required></textarea>
						</div>

						<div class="mb-3">
							<p>Et vous quelle voyage vous tente le plus?</p>

							<!-- On parcours tous les voyages entrées dans la base pour les ajouter un à un dans le groupe d'options -->
							<?php
								$sql = "SELECT id, nom FROM voyage";
								$res = $mysqli->query($sql);
								while ($row = $res->fetch_assoc())
									{
							?>
								<div class="form-check">
									<input class="form-check-input" type="radio" id="voyage-<?php echo $row['id'] ?>" name="voyage-favori" value="<?php echo $row['id'] ?>">
									<label class="form-check-label" for="voyage-<?php echo $row['id'] ?>"><?php echo $row['nom'] ?></label>
								</div>
							<?php
								}
							?>
						</div>
						<input type="submit" value="Valider" />
					</form>
					<div class="border-top">
						<h2>commentaires</h2>
						<!-- Si la resultat de la requête SQL est vide il n'y a pas de commentaire enregistré à afficher, on l'indique donc par un message
							 sinon on parcours chaque entrées de la base et on affiche le commentaire avec son auteur et la date à laquelle il a était écrit -->
						<?php
							$res = $mysqli->query("SELECT prenom, commentaire, date_commentaire FROM commentaire ORDER BY id DESC");
							if ($mysqli->affected_rows == 0) {
						?>
							<p>Il n'y a pas encore de commentaire pour cette article.</p>
						<?php
							} else {
							while ($row = $res->fetch_assoc())
							{
						?>
						<div class="commentaire border-top">
						    <p> <strong> <?php echo $row['prenom'] ?> </strong> le <?php echo date_format(date_create($row['date_commentaire']), ' j M Y') ?></p>
						    <p> <?php echo $row['commentaire'] ?> </p>
						</div>
						<?php 
							} }
						?>
						<button hidden id="plus-de-commentaires" type="button" class="btn btn-secondary btn-sm btn-lg col-12 mb-4">Voir plus de commentaires</button>
					</div>
				</div>
			</div>
		</div>

		<!-- j'ai ajouter un pied de page pour spécifier qu'il s'agit d'un exercice -->
		<!-- on ajoute un fond de couleur claire, une bordure au dessus du footer et on enlève la marge et le padding à la suite du footer -->
		<footer class="bg-light text-center border-top mb-0 p-0">
			<p class="justify-content-center m-0 p-4">Ce site est réalisé dans le cadre d'un exercice.</p>
		</footer>

		<!-- Bootstrap Bundle with Popper -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
		<script src="script.js"></script>
	</body>
</html>