<?php $root_path = "http://localhost/" ?>

<!-- une bar de navigation avec un "breakpoint" à md (768px)  -->
<nav class="navbar navbar-expand-md navbar-light bg-light">
	<div class="container">
		<a class="navbar-brand" href="#"><img src= <?php echo $root_path . "images/bicycle.png" ?> class="img-fluid" alt="icon du site"></a>

		<!-- si la fenêtre est < 768px les différents liens sont accessibles sous forme de menu deroulant en cliquant sur un bouton -->
		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<!-- sinon les liens sont directement afficher dans la bar de navigation --> 
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href= <?php echo $root_path ?> >en HTML5</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href= <?php echo $root_path . "avec-css/" ?> >+ CSS</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href= <?php echo $root_path . "avec-php/" ?> >+ php</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href= <?php echo $root_path . "avec-js/" ?> >+ js</a>
				</li>
			</ul>
		</div>
	</div>
</nav>