<?php
	$mysqli = new mysqli("localhost", "root", "password", "idees_de_voyage");
	if ($mysqli->connect_errno) {
        header('Location: /connection_error.php');
        exit();
	}
?>