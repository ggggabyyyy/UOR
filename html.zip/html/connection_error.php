<!DOCTYPE html>
<!-- l'attribut lang permet de définir la langue utilisée pour l'élément. Ici on utilise le français sur l'ensemble du document -->
<html lang="fr">
	<head>
		<title>Idées de voyage à vélo</title>

		<!-- permet de définir l'encodage des caractères -->
		<meta charset="utf-8">

		<!-- Permet de déclarer les 15 propriétés originales du Dublin Core -->
		<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
		<!-- Permet de déclarer d'autres propriétés du Dublin Core -->
		<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" />

		<!-- affectations des valeurs aux propriétés -->
		<meta name="DC.title" content="Idées de voyage à vélo">
		<meta name="DC.creator" content="Le touriste">
		<meta name="DC.subject" content="voyages, vélo, cyclotourisme">
		<meta name="DC.description" content="idées de projet de voyage en vélo">
		<meta name="DC.date" content="2021-08">
		<meta name="DC.type" content="text">
		<meta name="DC.source" content="https://fr.eurovelo.com, https://www.lfzuiderzeeroute.nl, https://www.avenuevertelondonparis.com/">
		<meta name="DC.language" content="fr">
		<meta name="DCTERMS.tableOfContents" content="Le Rhône à vélo de Andermatt à Genève, Le tour de l'IJsselmeer à vélo en partant d'Amsterdam, Paris - Londres">

		<!-- permet d'afficher le logo du site dans le navigateur -->
		<link rel="icon" type="image/png" href="../images/bicycle.png" />

		<!-- Bootsrap CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	</head>
	<body>

		<?php include("nav.php"); ?>

		<h2>Une erreur s'est produite lors de la connection à la base de données.</h2>
		

		<!-- Bootstrap Bundle with Popper -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
	</body>
</html>