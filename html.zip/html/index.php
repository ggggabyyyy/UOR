<!DOCTYPE html>
<!-- l'attribut lang permet de définir la langue utilisée pour l'élément. Ici on utilise le français sur l'ensemble du document -->
<html lang="fr">
	<head>
		<title>Idées de voyage à vélo</title>

		<!-- permet de définir l'encodage des caractères -->
		<meta charset="utf-8">

		<!-- Permet de déclarer les 15 propriétés originales du Dublin Core -->
		<link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
		<!-- Permet de déclarer d'autres propriétés du Dublin Core -->
		<link rel="schema.DCTERMS" href="http://purl.org/dc/terms/" />

		<!-- affectations des valeurs aux propriétés -->
		<meta name="DC.title" content="Idées de voyage à vélo">
		<meta name="DC.creator" content="Le touriste">
		<meta name="DC.subject" content="voyages, vélo, cyclotourisme">
		<meta name="DC.description" content="idées de projet de voyage en vélo">
		<meta name="DC.date" content="2021-08">
		<meta name="DC.type" content="text">
		<meta name="DC.source" content="https://fr.eurovelo.com, https://www.lfzuiderzeeroute.nl, https://www.avenuevertelondonparis.com/">
		<meta name="DC.language" content="fr">
		<meta name="DCTERMS.tableOfContents" content="Le Rhône à vélo de Andermatt à Genève, Le tour de l'IJsselmeer à vélo en partant d'Amsterdam, Paris - Londres">

		<!-- permet d'afficher le logo du site dans le navigateur -->
		<link rel="icon" type="image/png" href="images/bicycle.png" />

		<!-- Bootsrap CSS -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	</head>
	<body>

		<?php include("nav.php"); ?>

		<!-- je place dans l'en tête le titre de la page et une petite intro -->
		<header>
			<h1>Quelques idées de voyage à vélo</h1>
			<p>Suite à une super expérience de voyage à vélo le long de la côte atlantique de Nantes à Arcachon, j'ai prévu de faire d'autres voyages à vélo. En voici quelques-uns.</p>
		</header>

		<!-- bloc divisé en trois articles -->
		<div>
			<article>
				<!-- chaque article possède un titre en h2 pour différencier du titre de la page -->
				<h2>Le Rhône à vélo de Andermatt à Genève</h2>

				<!-- une image qui montre la carte du parcours -->
				<img src="images/carte_route_du_rhone.png" alt="carte de l'itinéraire de la route du Rhône">

				<!-- un premier paragraphe qui parle du parcours 
					j'ai mis en avant les 3700m pour éviter que l'on s'attarde sur cet article
					si l'on veut un voyage moins exigeant -->
				<p>
					Parcours de 350km dans la vallée du Rhône, en partant d'Andermatt, une petite ville située dans l'une des vallées les plus imposante de Suisses. En tout <em>3700 m de montée cumulée</em>, située essentiellement en début de parcours pour rejoindre le glacier du Rhône. Le dénivelé du parcours est de -1000m. Pour les plus sportifs il peut être intéressant de le faire dans l'autre sens.
				</p>

				<!-- une partie qui liste des sites à voir sur le parcours -->
				<div>
					<h3>A voir sur le parcours:</h3>
					<ul>
						<li><a href="https://fr.wikipedia.org/wiki/Glacier_du_Rh%C3%B4ne">le glacier du Rhône</a></li>
						<li><a href="https://fr.wikipedia.org/wiki/Ch%C3%A2teau_de_Stockalper">le Chateau Kaspar Stockalper</a></li>
						<li>le lac Léman et les villes de Lausanne et Genève</li>
					</ul>
				</div>

				<!-- une dernière partie pour des infos pratiques et des liens pour approfondir le sujet -->
				<p>
					Accès à Andermatt depuis Paris : environ 7h-8h en train<br>
					Pour plus d'info sur le parcours : le site de <a href="https://www.schweizmobil.ch/fr/suisse-a-velo/itineraires/route-01.html">schweizmobil</a> ou d'<a href="https://fr.eurovelo.com/ev17/points-of-interest-on-eurovelo-17">eurovelo</a>
				</p>
			</article>
			<article>
				<h2>Le tour de l'IJsselmeer à vélo en partant d'Amsterdam</h2>
				<img src="images/carte_zuiderzeeroute.png" class="img-fluid" alt="carte de l'itinéraire de la zuiderzeeroute">
				<p>
					La zuiderzeeroute est très plate (une évidence aux Pays-Bas) et est longue de 440km. Elle fait le tour de l'IJsselmeer en passant par <a href="https://fr.wikipedia.org/wiki/Afsluitdijk">l'Afsluitdijk</a> <em>une digue de 32km!</em> Ce parcours est à faire de préference entre mi-avril et fin mai pour profiter des <a href="https://www.holland.com/fr/tourisme/destinations/les-provinces/flevoland/fleurs-en-flevoland.htm">champs de tulipes du Flevoland</a>
				</p>
				<div>
					<h3>A voir sur le parcours:</h3>
					<ul>
						<li>Amsterdam</li>
						<li>les champs de tulipes (mi-avril à mai à Dronten, Lelystad et Putten)</li>
						<li>les moulins</li>
					</ul>
				</div>
				<p>
					Accès à Amsterdam depuis Paris : 2h en train<br>
					Pour plus d'info sur le parcours : <a href="https://www.lfzuiderzeeroute.nl/en">lfzuiderzeeroute.nl/en</a>
				</p>
			</article>
			<article>
				<h2>Paris - Londres</h2>
				<img src="images/carte_paris_londres.png" class="img-fluid" alt="carte de l'itinéraire Paris-Londres">
				<p>
					Départ de Paris puis passage par la vallée de l'Epte en Normandie avant de rejoindre Dieppe. La traversée de la Manche se fait en 3h de <a href="https://www.dfds.com/fr-fr/ferries-passagers/lignes-ferries/ferries-vers-angleterre/dieppe-newhaven">ferry de Dieppe à Newhaven</a>. Il reste ensuite 159km pour rejoindre la capitale Britannique. Une alternative et de longer les bords de l'Oise avant de se diriger vers la Normandie, ce qui rallonge le parcours de 66km mais permet de longer plusieurs jolis châteaux au passage.
				</p>
				<div>
					<h3>A voir sur le parcours:</h3>
					<ul>
						<li><a href="https://fr.wikipedia.org/wiki/Fondation_Claude_Monet">la Fondation Claude Monet à Giverny</a></li>
						<li>quelques châteaux à voir, comme par exemple celui de <a href="https://fr.wikipedia.org/wiki/Ch%C3%A2teau_de_Gisors">Gisors</a></li>
						<li>et Londres bien sûr.</li>
					</ul>
				</div>
				<p>
					retour Londres-Paris : 2h20 en train<br>
					Pour plus d'info sur le parcours : <a href="https://www.avenuevertelondonparis.com/">avenuevertelondonparis.com</a>
				</p>
			</article>
		</div>

		<!-- un tableau récapitulatif des voyages placé entre les balises aside
				 cela permettra d'avoir un aperçu rapide sur les différents voyages -->
		<aside>
			<h2>Tableau récapitulatif des voyages</h2>
			<table>
				<tr>
					<th>trajet</th>
					<th>paysage</th>
					<th>période</th>
					<th>distance</th>
					<th>durée</th>
				</tr>
				<tr>
					<td>Andermatt (Suisse) - Genève</td>
					<td>montagne</td>
					<td>printemps-été</td>
					<td>350 km</td>
					<td>8 j.</td>
				</tr>
				<tr>
					<td>Tour de l'IJsselmeer (Pays-Bas)</td>
					<td>lac - champs</td>
					<td>mi-avril - mai</td>
					<td>440 km</td>
					<td>8 j.</td>
				</tr>
				<tr>
					<td>Paris - Londres</td>
					<td>varié</td>
					<td>toute l'année</td>
					<td>406 km</td>
					<td>8 j.</td>
				</tr>
			</table>
		</aside>

		<!-- j'ai ajouter un pied de page pour spécifier qu'il s'agit d'un exercice -->
		<footer>
			<p>Ce site est réalisé dans le cadre d'un exercice.</p>
		</footer>

		<!-- Bootstrap Bundle with Popper -->
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

	</body>
</html>